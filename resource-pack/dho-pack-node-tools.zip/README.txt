DHO Manager .dho-pack Node 제작 도구

요구 사항: Node.js 20 이상

처음 만드는 경우:
- examples/poi-data-basic: 추가 거점 최소 예제
- examples/visual-theme: GUI·HUD·지도·항해선·마커 전체 테마 예제
- schema/: JSON 편집기와 AI 에이전트용 JSON Schema
- AGENT-GUIDE.txt: 자동화 도구가 읽을 전체 규격과 작업 순서

원본 팩 폴더 검사:
node tools/validate-pack.mjs my-pack

.dho-pack 생성:
node tools/build-dho-pack.mjs my-pack output/my-pack.dho-pack

생성된 아카이브 재검사:
node tools/verify-archive.mjs output/my-pack.dho-pack

빌드 도구는 .DS_Store와 __MACOSX를 제외하고 manifest.json의 files SHA-256을
자동 생성합니다. 압축을 손으로 다시 만들지 마세요.

사람용 문서: https://manager.dhoport.app/resource-pack/docs/
사람과 AI의 공통 제작 흐름: https://manager.dhoport.app/resource-pack/docs/agent/
