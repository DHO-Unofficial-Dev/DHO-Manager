#!/usr/bin/env node
import { readFile } from 'node:fs/promises';
import { readZip, validatePackFiles } from './dho-pack-lib.mjs';

const input = process.argv[2];
if (!input) throw new Error('사용법: node tools/verify-archive.mjs <파일.dho-pack>');
const files = readZip(await readFile(input));
const errors = validatePackFiles(files);
if (errors.length) {
  console.error(errors.map((error) => `- ${error}`).join('\n'));
  process.exitCode = 1;
} else console.log(`아카이브 검증 완료: ${files.size - 1}개 콘텐츠 파일`);
