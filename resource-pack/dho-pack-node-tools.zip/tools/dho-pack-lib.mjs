import { createHash } from 'node:crypto';
import { readdir, readFile } from 'node:fs/promises';
import { relative, resolve, sep } from 'node:path';
import { inflateRawSync } from 'node:zlib';
import { DEFAULT_MAP_THEME, makeStoredZip } from '../landing/resource-pack/builder-core.js';

const ID = /^[a-z0-9][a-z0-9._-]{0,127}$/;
const SEMVER = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z.-]+)?$/;
const COLOR = /^#[0-9a-fA-F]{6}$/;
const SHA256 = /^sha256:[0-9a-f]{64}$/;
const COMPONENTS = ['mapData', 'poiData', 'markerSet', 'infoPanelSkin', 'steeringHudSkin', 'mapHudSkin', 'appIcon'];
const INFO_COLORS = ['panelBackground', 'panelBorder', 'primaryText', 'secondaryText', 'mutedText', 'accent', 'routeHighlight', 'status', 'rule', 'arrivalBackground', 'arrivalBorder', 'arrivalText', 'editBackground', 'editText', 'editBorder', 'editControlBorder'];
const NAVIGATOR_COLORS = ['background', 'surface', 'text', 'mutedText', 'line', 'rule', 'accent', 'danger', 'focus'];
const STEERING_COLORS = ['neutral', 'surface'];
const STEERING_GUIDANCE_COLORS = ['direction', 'target', 'aligned', 'centerMarker'];
const STEERING_OPACITY = ['guideLine', 'tick', 'majorTick', 'minorTick', 'compassText', 'minorCompassText', 'centerLabel', 'targetMarkerSurface', 'targetLabelSurface'];
const MAP_COLORS = ['surface', 'text', 'mutedText', 'border', 'accent', 'connected', 'waiting', 'editText'];
const MAP_FRAME = ['statusSurfaceOpacity', 'highlightedSurfaceOpacity', 'borderOpacity', 'editSurfaceOpacity'];
const encoder = new TextEncoder();

function sha256(bytes) {
  return `sha256:${createHash('sha256').update(bytes).digest('hex')}`;
}

function cleanPath(path) {
  return path.replaceAll('\\', '/').replace(/^\.\//, '');
}

function safePath(path) {
  return path && path === cleanPath(path) && !path.startsWith('/') && !path.split('/').some((part) => !part || part === '.' || part === '..');
}

function ignoredPath(path) {
  const parts = cleanPath(path).split('/');
  return parts.includes('.DS_Store') || parts.includes('__MACOSX');
}

function httpsOrAbsent(value) {
  if (value === undefined) return true;
  try { return new URL(value).protocol === 'https:'; }
  catch { return false; }
}

export async function readSourceDirectory(directory) {
  const root = resolve(directory);
  const files = new Map();
  async function visit(current) {
    for (const entry of await readdir(current, { withFileTypes: true })) {
      const absolute = resolve(current, entry.name);
      const path = cleanPath(relative(root, absolute).split(sep).join('/'));
      if (ignoredPath(path)) continue;
      if (entry.isDirectory()) await visit(absolute);
      else if (entry.isFile()) files.set(path, new Uint8Array(await readFile(absolute)));
    }
  }
  await visit(root);
  return files;
}

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
  }
  return (crc ^ 0xffffffff) >>> 0;
}

export function readZip(bytes) {
  const data = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  if (data.byteLength > 16 * 1024 * 1024) throw new Error('리소스팩 크기는 16MB 이하여야 합니다.');
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  let eocd = -1;
  for (let index = data.byteLength - 22; index >= Math.max(0, data.byteLength - 65557); index -= 1) {
    if (view.getUint32(index, true) === 0x06054b50) { eocd = index; break; }
  }
  if (eocd < 0) throw new Error('유효한 ZIP 중앙 디렉터리가 없습니다.');
  const count = view.getUint16(eocd + 10, true);
  let cursor = view.getUint32(eocd + 16, true);
  const files = new Map();
  const decoder = new TextDecoder();
  for (let index = 0; index < count; index += 1) {
    if (view.getUint32(cursor, true) !== 0x02014b50) throw new Error('ZIP 중앙 디렉터리가 손상되었습니다.');
    const flags = view.getUint16(cursor + 8, true);
    const method = view.getUint16(cursor + 10, true);
    const expectedCrc = view.getUint32(cursor + 16, true);
    const compressedSize = view.getUint32(cursor + 20, true);
    const originalSize = view.getUint32(cursor + 24, true);
    const nameLength = view.getUint16(cursor + 28, true);
    const extraLength = view.getUint16(cursor + 30, true);
    const commentLength = view.getUint16(cursor + 32, true);
    const localOffset = view.getUint32(cursor + 42, true);
    const name = cleanPath(decoder.decode(data.subarray(cursor + 46, cursor + 46 + nameLength)));
    cursor += 46 + nameLength + extraLength + commentLength;
    if (name.endsWith('/') || ignoredPath(name)) continue;
    if (!safePath(name) || files.has(name)) throw new Error(`안전하지 않거나 중복된 경로입니다: ${name}`);
    if (flags & 1) throw new Error(`암호화된 ZIP 항목은 지원하지 않습니다: ${name}`);
    if (view.getUint32(localOffset, true) !== 0x04034b50) throw new Error(`ZIP 항목이 손상되었습니다: ${name}`);
    const localNameLength = view.getUint16(localOffset + 26, true);
    const localExtraLength = view.getUint16(localOffset + 28, true);
    const start = localOffset + 30 + localNameLength + localExtraLength;
    const compressed = data.subarray(start, start + compressedSize);
    const content = method === 0 ? compressed : method === 8 ? new Uint8Array(inflateRawSync(compressed)) : null;
    if (!content) throw new Error(`지원하지 않는 ZIP 압축 방식입니다: ${method}`);
    if (content.byteLength !== originalSize || crc32(content) !== expectedCrc) throw new Error(`ZIP 항목 검증에 실패했습니다: ${name}`);
    files.set(name, content);
  }
  return files;
}

function parseJson(files, path, errors) {
  const bytes = files.get(path);
  if (!bytes) { errors.push(`참조한 파일이 없습니다: ${path}`); return null; }
  try { return JSON.parse(new TextDecoder().decode(bytes)); }
  catch { errors.push(`JSON을 해석할 수 없습니다: ${path}`); return null; }
}

function requiredColors(value, tokens, label, errors) {
  if (!value || typeof value !== 'object') { errors.push(`${label} 색상 토큰이 없습니다.`); return; }
  for (const token of tokens) if (!COLOR.test(String(value[token] ?? ''))) errors.push(`${label} ${token} 색상은 #RRGGBB 형식이어야 합니다.`);
}

function number(value, minimum, maximum, label, errors) {
  if (!Number.isFinite(value) || value < minimum || value > maximum) errors.push(`${label} 값은 ${minimum}~${maximum}이어야 합니다.`);
}

function thumbnailDimensions(path, bytes) {
  if (path.toLowerCase().endsWith('.png')) {
    if (bytes.length < 24 || ![137, 80, 78, 71, 13, 10, 26, 10].every((byte, index) => bytes[index] === byte) || new TextDecoder().decode(bytes.subarray(12, 16)) !== 'IHDR') return null;
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    return [view.getUint32(16), view.getUint32(20)];
  }
  if (path === 'thumbnail.webp' && bytes.length >= 16 && new TextDecoder().decode(bytes.subarray(0, 4)) === 'RIFF' && new TextDecoder().decode(bytes.subarray(8, 12)) === 'WEBP') {
    const chunk = new TextDecoder().decode(bytes.subarray(12, 16));
    if (chunk === 'VP8X' && bytes.length >= 30) {
      const width = 1 + bytes[24] + (bytes[25] << 8) + (bytes[26] << 16);
      const height = 1 + bytes[27] + (bytes[28] << 8) + (bytes[29] << 16);
      return [width, height];
    }
    if (chunk === 'VP8L' && bytes.length >= 25 && bytes[20] === 0x2f) {
      const bits = bytes[21] | (bytes[22] << 8) | (bytes[23] << 16) | (bytes[24] << 24);
      return [(bits & 0x3fff) + 1, ((bits >>> 14) & 0x3fff) + 1];
    }
    if (chunk === 'VP8 ' && bytes.length >= 30 && bytes[23] === 0x9d && bytes[24] === 0x01 && bytes[25] === 0x2a) {
      const width = (bytes[26] | (bytes[27] << 8)) & 0x3fff;
      const height = (bytes[28] | (bytes[29] << 8)) & 0x3fff;
      return [width, height];
    }
  }
  if (path === 'thumbnail.gif' && bytes.length >= 10 && ['GIF87a', 'GIF89a'].includes(new TextDecoder().decode(bytes.subarray(0, 6)))) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    return [view.getUint16(6, true), view.getUint16(8, true)];
  }
  if (['thumbnail.jpg', 'thumbnail.jpeg'].includes(path) && bytes.length >= 4 && bytes[0] === 0xff && bytes[1] === 0xd8) {
    const sofMarkers = new Set([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf]);
    let position = 2;
    while (position + 1 < bytes.length) {
      while (position < bytes.length && bytes[position] !== 0xff) position += 1;
      while (position < bytes.length && bytes[position] === 0xff) position += 1;
      const marker = bytes[position];
      position += 1;
      if (marker === 0xd9 || marker === 0xda || marker === undefined) break;
      if (marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) continue;
      if (position + 1 >= bytes.length) return null;
      const segmentLength = (bytes[position] << 8) | bytes[position + 1];
      if (segmentLength < 2 || position + segmentLength > bytes.length) return null;
      if (sofMarkers.has(marker) && segmentLength >= 7) {
        return [
          (bytes[position + 5] << 8) | bytes[position + 6],
          (bytes[position + 3] << 8) | bytes[position + 4],
        ];
      }
      position += segmentLength;
    }
  }
  return null;
}

function validateSkin(component, type, errors) {
  if (!component || typeof component !== 'object' || !ID.test(String(component.id ?? '')) || typeof component.name !== 'string' || !component.name.trim()) {
    errors.push(`${type} 식별 정보가 올바르지 않습니다.`); return;
  }
  if (type === 'infoPanelSkin') {
    requiredColors(component.colors, INFO_COLORS, '정보 패널', errors);
    if (!component.frame) errors.push('정보 패널 프레임 토큰이 없습니다.');
    else { number(component.frame.borderWidth, 0, 4, '테두리 굵기', errors); number(component.frame.cornerRadius, 0, 24, '모서리 크기', errors); number(component.frame.backdropBlur, 0, 20, '배경 흐림', errors); if (!['none', 'soft', 'strong'].includes(component.frame.shadow)) errors.push('지원하지 않는 그림자 값입니다.'); }
    if (component.navigator) { requiredColors(component.navigator.colors, NAVIGATOR_COLORS, '네비게이터', errors); number(component.navigator.cornerRadius, 0, 24, '네비게이터 모서리', errors); }
  } else if (type === 'steeringHudSkin') {
    requiredColors(component.colors, STEERING_COLORS, '조향 HUD', errors);
    if (component.guidanceColors) requiredColors(component.guidanceColors, STEERING_GUIDANCE_COLORS, '조향 안내', errors);
    for (const token of STEERING_OPACITY) number(component.opacity?.[token], 0, 1, `조향 HUD ${token}`, errors);
    for (const [token, range] of Object.entries({ verticalLength: [8, 256], horizontalLength: [8, 256], diamondSize: [4, 64], lineWidth: [1, 4] })) number(component.centerMarker?.[token], ...range, `중앙 표식 ${token}`, errors);
  } else {
    requiredColors(component.colors, MAP_COLORS, '지도 HUD', errors);
    for (const token of MAP_FRAME) number(component.frame?.[token], 0, 1, `지도 HUD ${token}`, errors);
    number(component.frame?.editBorderWidth, 1, 4, '지도 HUD editBorderWidth', errors);
    if (component.mapTheme) for (const [token, defaultValue] of Object.entries(DEFAULT_MAP_THEME)) {
      const value = component.mapTheme[token];
      if (typeof defaultValue === 'boolean' && typeof value !== 'boolean') errors.push(`지도 테마 ${token} 값이 올바르지 않습니다.`);
      else if (token.endsWith('Color') && !COLOR.test(String(value))) errors.push(`지도 테마 ${token} 색상은 #RRGGBB 형식이어야 합니다.`);
      else if (token.endsWith('Opacity')) number(value, 0, 1, `지도 테마 ${token}`, errors);
      else if (token.endsWith('Width')) number(value, 0, 6, `지도 테마 ${token}`, errors);
      else if (token.endsWith('Size')) number(value, 0, 24, `지도 테마 ${token}`, errors);
      else if (token.endsWith('Pattern') && !['solid', 'dashed', 'dotted'].includes(value)) errors.push(`지도 테마 ${token} 값이 올바르지 않습니다.`);
    }
    if (component.navigationTheme) for (const token of ['course', 'compass', 'mouse', 'track', 'route']) {
      const line = component.navigationTheme[token];
      if (!line || !COLOR.test(String(line.color ?? '')) || !['solid', 'dashed', 'dotted'].includes(line.pattern)) errors.push(`항해선 테마 ${token} 값이 올바르지 않습니다.`);
      else { number(line.width, 0.25, 8, `항해선 ${token} 굵기`, errors); number(line.opacity, 0, 1, `항해선 ${token} 투명도`, errors); }
    }
  }
}

export async function normalizeManifestFiles(files) {
  const manifest = parseJson(files, 'manifest.json', []);
  if (!manifest) throw new Error('manifest.json이 없거나 올바르지 않습니다.');
  manifest.files = {};
  for (const [path, bytes] of [...files].sort(([a], [b]) => a.localeCompare(b))) if (path !== 'manifest.json') manifest.files[path] = sha256(bytes);
  const normalized = new Map(files);
  normalized.set('manifest.json', encoder.encode(`${JSON.stringify(manifest, null, 2)}\n`));
  return normalized;
}

export function validatePackFiles(files) {
  const errors = [];
  const manifest = parseJson(files, 'manifest.json', errors);
  if (!manifest) return errors;
  if (manifest.formatVersion !== 1) errors.push('formatVersion은 1이어야 합니다.');
  if (!ID.test(String(manifest.packId ?? ''))) errors.push('packId가 올바르지 않습니다.');
  if (!SEMVER.test(String(manifest.version ?? ''))) errors.push('version은 SemVer여야 합니다.');
  for (const field of ['name', 'author', 'license']) if (typeof manifest[field] !== 'string' || !manifest[field].trim()) errors.push(`${field} 값이 필요합니다.`);
  const publisherMatches = manifest.publisher && (manifest.packId === manifest.publisher.id || String(manifest.packId ?? '').startsWith(`${manifest.publisher.id}.`));
  if (!manifest.publisher || !ID.test(String(manifest.publisher.id ?? '')) || !manifest.publisher.name || !publisherMatches || !httpsOrAbsent(manifest.publisher.url)) errors.push('publisher 또는 packId 네임스페이스가 올바르지 않습니다.');
  if (!manifest.source?.name) errors.push('source.name이 필요합니다.');
  if (!httpsOrAbsent(manifest.source?.url) || !httpsOrAbsent(manifest.update?.manifestUrl)) errors.push('source, publisher와 update 주소는 HTTPS여야 합니다.');
  if (!SEMVER.test(String(manifest.compatibility?.minimumManagerVersion ?? ''))) errors.push('minimumManagerVersion이 올바르지 않습니다.');
  const components = manifest.components;
  if (!components || typeof components !== 'object' || !Object.keys(components).length) errors.push('구성요소가 하나 이상 필요합니다.');
  for (const key of Object.keys(components || {})) if (!COMPONENTS.includes(key)) errors.push(`지원하지 않는 구성요소입니다: ${key}`);
  for (const [component, requirements] of Object.entries(manifest.componentRequirements || {})) {
    if (!COMPONENTS.includes(component) || !components?.[component] || !Array.isArray(requirements) || new Set(requirements).size !== requirements.length) errors.push(`구성요소 의존성이 올바르지 않습니다: ${component}`);
    else for (const required of requirements) if (required === component || !COMPONENTS.includes(required) || !components?.[required]) errors.push(`구성요소 의존 대상이 올바르지 않습니다: ${component} -> ${required}`);
  }
  for (const path of files.keys()) if (path !== 'manifest.json' && !Object.hasOwn(manifest.files || {}, path)) errors.push(`files에 선언되지 않은 파일입니다: ${path}`);
  for (const [path, expected] of Object.entries(manifest.files || {})) {
    if (!safePath(path) || path === 'manifest.json' || !SHA256.test(String(expected))) errors.push(`files 선언이 올바르지 않습니다: ${path}`);
    else if (!files.has(path)) errors.push(`files에 선언한 파일이 없습니다: ${path}`);
    else if (sha256(files.get(path)) !== expected) errors.push(`SHA-256이 일치하지 않습니다: ${path}`);
  }
  if (manifest.thumbnail !== undefined) {
    if (!['thumbnail.webp', 'thumbnail.png', 'thumbnail.jpg', 'thumbnail.jpeg', 'thumbnail.gif'].includes(manifest.thumbnail)) {
      errors.push('thumbnail은 루트의 thumbnail.webp, thumbnail.png, thumbnail.jpg, thumbnail.jpeg 또는 thumbnail.gif여야 합니다.');
    } else {
      const thumbnail = files.get(manifest.thumbnail);
      const dimensions = thumbnail && thumbnailDimensions(manifest.thumbnail, thumbnail);
      if (!thumbnail) errors.push(`팩 썸네일 파일이 없습니다: ${manifest.thumbnail}`);
      else if (thumbnail.byteLength > 512 * 1024) errors.push('팩 썸네일은 512KB 이하여야 합니다.');
      else if (!dimensions || dimensions[0] <= 0 || dimensions[1] <= 0 || dimensions[0] > 1024 || dimensions[1] > 1024) errors.push('팩 썸네일 이미지 또는 해상도가 올바르지 않습니다.');
    }
  }
  for (const type of ['infoPanelSkin', 'steeringHudSkin', 'mapHudSkin']) if (components?.[type]) validateSkin(components[type], type, errors);
  if (components?.mapData) for (const field of ['coastline', 'seaRegions']) if (!safePath(components.mapData[field]) || !files.has(components.mapData[field])) errors.push(`mapData ${field} 파일이 없습니다.`);
  if (components?.poiData && (!safePath(components.poiData.source) || !parseJson(files, components.poiData.source, errors))) errors.push('poiData source가 올바르지 않습니다.');
  if (components?.appIcon) {
    const appIcon = components.appIcon;
    const slots = ['window'];
    if (!appIcon || typeof appIcon !== 'object' || Array.isArray(appIcon)
      || Object.keys(appIcon).some((key) => !slots.includes(key))
      || typeof appIcon.window !== 'string') {
      errors.push('appIcon은 window PNG 경로가 필요합니다.');
    } else for (const slot of slots) {
      const path = appIcon[slot];
      if (path === undefined) continue;
      const bytes = files.get(path);
      const dimensions = bytes && thumbnailDimensions(path, bytes);
      if (!safePath(path) || !path.toLowerCase().endsWith('.png') || !bytes) {
        errors.push(`appIcon.${slot} PNG 파일이 없습니다.`);
      } else if (bytes.byteLength > 512 * 1024) {
        errors.push(`appIcon.${slot}은 512KB 이하여야 합니다.`);
      } else if (!dimensions || dimensions[0] !== dimensions[1]
        || dimensions[0] < 16 || dimensions[0] > 512) {
        errors.push(`appIcon.${slot}은 16~512px 정사각 PNG여야 합니다.`);
      }
    }
  }
  if (components?.markerSet?.assets) for (const [id, asset] of Object.entries(components.markerSet.assets)) {
    if (!ID.test(id) || !asset || !safePath(asset.path) || !files.has(asset.path)) errors.push(`마커 자산 참조가 올바르지 않습니다: ${id}`);
    if (asset) { number(asset.displayWidth, 4, 256, `마커 ${id} 너비`, errors); number(asset.displayHeight, 4, 256, `마커 ${id} 높이`, errors); number(asset.anchorX, 0, 1, `마커 ${id} anchorX`, errors); number(asset.anchorY, 0, 1, `마커 ${id} anchorY`, errors); }
    if (asset?.path?.toLowerCase().endsWith('.svg') && files.has(asset.path)) {
      const svg = new TextDecoder().decode(files.get(asset.path));
      const namespace = 'http://www.w3.org/2000/svg';
      const namespaceCount = svg.toLowerCase().split(namespace).length - 1;
      const inspected = svg.toLowerCase().replace(/xmlns\s*=\s*(["'])http:\/\/www\.w3\.org\/2000\/svg\1/, 'xmlns=""');
      if (namespaceCount > 1 || !/<svg\b[^>]*\bviewbox\s*=/.test(inspected) || /<!doctype|<!entity|<script|<style|<foreignobject|<image|<use|<animate|<set|<iframe|<object|<embed|\bhref\s*=|xlink:href|url\(|@import|javascript:|data:|http:|https:|\son[a-z0-9-]+\s*=/.test(inspected)) errors.push(`SVG 마커 자산이 안전하지 않습니다: ${id}`);
    }
  }
  const customMarkerTypes = components?.markerSet?.personal?.customTypes;
  if (customMarkerTypes !== undefined) {
    const assetIds = new Set(Object.keys(components?.markerSet?.assets || {}));
    const fallbackIcons = new Set(['star', 'port', 'trade', 'danger', 'discovery', 'memo']);
    if (!customMarkerTypes || typeof customMarkerTypes !== 'object' || Array.isArray(customMarkerTypes)) errors.push('추가 개인 표식 유형 목록이 객체가 아닙니다.');
    else if (Object.keys(customMarkerTypes).length > 32) errors.push('추가 개인 표식 유형은 최대 32개까지 허용됩니다.');
    else for (const [id, type] of Object.entries(customMarkerTypes)) {
      if (!ID.test(id) || !id.includes('.') || !type || typeof type !== 'object' || Array.isArray(type)) errors.push(`추가 개인 표식 유형 선언이 올바르지 않습니다: ${id}`);
      else {
        if (typeof type.name !== 'string' || !type.name.trim() || type.name.length > 40) errors.push(`추가 개인 표식 유형 이름이 올바르지 않습니다: ${id}`);
        if (!fallbackIcons.has(type.fallbackIcon)) errors.push(`추가 개인 표식 폴백 아이콘이 올바르지 않습니다: ${id}`);
        if (type.asset !== undefined && (typeof type.asset !== 'string' || !assetIds.has(type.asset))) errors.push(`추가 개인 표식 자산 참조가 올바르지 않습니다: ${id}`);
      }
    }
  }
  return [...new Set(errors)];
}

export async function buildArchiveFromDirectory(directory) {
  const files = await normalizeManifestFiles(await readSourceDirectory(directory));
  const errors = validatePackFiles(files);
  if (errors.length) throw new Error(errors.join('\n'));
  return { files, bytes: makeStoredZip(files) };
}
