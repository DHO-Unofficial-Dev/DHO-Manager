#!/usr/bin/env node
import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, extname, resolve } from 'node:path';
import { buildArchiveFromDirectory } from './dho-pack-lib.mjs';

const [source, output] = process.argv.slice(2);
if (!source || !output) throw new Error('사용법: node tools/build-dho-pack.mjs <원본 폴더> <출력.dho-pack>');
if (extname(output).toLowerCase() !== '.dho-pack') throw new Error('출력 확장자는 .dho-pack이어야 합니다.');
const result = await buildArchiveFromDirectory(source);
await mkdir(dirname(resolve(output)), { recursive: true });
await writeFile(output, result.bytes);
console.log(`리소스팩 생성 완료: ${resolve(output)} (${result.files.size - 1}개 콘텐츠 파일)`);
