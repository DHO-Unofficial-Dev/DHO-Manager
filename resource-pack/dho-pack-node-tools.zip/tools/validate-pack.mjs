#!/usr/bin/env node
import { readFile, stat } from 'node:fs/promises';
import { readSourceDirectory, readZip, normalizeManifestFiles, validatePackFiles } from './dho-pack-lib.mjs';

const input = process.argv[2];
if (!input) throw new Error('사용법: node tools/validate-pack.mjs <원본 폴더 또는 .dho-pack>');
const info = await stat(input);
const files = info.isDirectory()
  ? await normalizeManifestFiles(await readSourceDirectory(input))
  : readZip(await readFile(input));
const errors = validatePackFiles(files);
if (errors.length) {
  console.error(errors.map((error) => `- ${error}`).join('\n'));
  process.exitCode = 1;
} else console.log(`검증 완료: ${files.size - 1}개 콘텐츠 파일`);
